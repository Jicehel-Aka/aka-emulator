// launcher_config.h - constantes communes du Launcher AKA.
#pragma once
#include <cstddef>
#include <cstdint>

namespace launcher {

constexpr const char* kSdRoot        = "/sdcard";
constexpr const char* kFirmwareName  = "firmware.bin";
constexpr const char* kMetaName      = "meta.json";
constexpr const char* kScreenName    = "screen.bpm";

constexpr size_t kMaxApps            = 64;     // applications listees
constexpr size_t kMaxTextLen         = 96;     // titre, auteur...
constexpr size_t kMaxDescLen         = 192;
constexpr size_t kMaxPreviewW        = 160;    // apercu 4:3
constexpr size_t kMaxPreviewH        = 120;

constexpr uint32_t kComboHoldMs      = 500;    // [HOME]+[MENU] -> Launcher
constexpr size_t   kFlashChunk       = 4096;   // taille de lecture/ecriture

}  // namespace launcher
