#include "flasher.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_image_format.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_system.h"
#include "launcher_config.h"

namespace launcher {

namespace {

const char* TAG = "flasher";
constexpr uint8_t kImageMagic = 0xE9;   // ESP_IMAGE_HEADER_MAGIC

// Partition de l'application : la premiere de sous-type OTA_0 (comme le fait
// la table de partitions de la console, sans offset code en dur).
const esp_partition_t* applicationPartition()
{
    return esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, nullptr);
}

}  // namespace

const char* errorKey(FlashResult r)
{
    switch (r) {
    case FlashResult::Ok:                return "OK";
    case FlashResult::NoTargetPartition: return "LAUNCHER_ERR_NO_PART";
    case FlashResult::TargetIsRunning:   return "LAUNCHER_ERR_RUNNING";
    case FlashResult::OpenFailed:        return "LAUNCHER_ERR_OPEN";
    case FlashResult::NotAnImage:        return "LAUNCHER_ERR_IMAGE";
    case FlashResult::TooBig:            return "LAUNCHER_ERR_BIG";
    case FlashResult::BeginFailed:       return "LAUNCHER_ERR_BEGIN";
    case FlashResult::ReadFailed:        return "LAUNCHER_ERR_READ";
    case FlashResult::WriteFailed:       return "LAUNCHER_ERR_WRITE";
    case FlashResult::ValidationFailed:  return "LAUNCHER_ERR_VALID";
    case FlashResult::SetBootFailed:     return "LAUNCHER_ERR_BOOT";
    case FlashResult::NotApplicable:     return "OK";
    }
    return "?";
}

FlashResult flashApp(const char* path, ProgressFn progress, void* ctx)
{
    const esp_partition_t* target = applicationPartition();
    if (!target) return FlashResult::NoTargetPartition;
    if (target == esp_ota_get_running_partition()) return FlashResult::TargetIsRunning;

    FILE* f = fopen(path, "rb");
    if (!f) return FlashResult::OpenFailed;

    fseek(f, 0, SEEK_END);
    const long total = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (total < 32) { fclose(f); return FlashResult::NotAnImage; }
    if ((size_t)total > target->size) { fclose(f); return FlashResult::TooBig; }

    uint8_t* buf = (uint8_t*)malloc(kFlashChunk);
    if (!buf) { fclose(f); return FlashResult::BeginFailed; }

    FlashResult result = FlashResult::Ok;
    esp_ota_handle_t handle = 0;
    bool begun = false;

    do {
        // Premier bloc : controle de l'en-tete avant d'effacer quoi que ce soit.
        size_t n = fread(buf, 1, kFlashChunk, f);
        if (n == 0) { result = FlashResult::ReadFailed; break; }
        if (buf[0] != kImageMagic) { result = FlashResult::NotAnImage; break; }

        // esp_ota_begin efface la zone necessaire ; l'ecriture sequentielle
        // permet de n'effacer que ce qui est ecrit.
        if (esp_ota_begin(target, (size_t)total, &handle) != ESP_OK) {
            result = FlashResult::BeginFailed;
            break;
        }
        begun = true;

        size_t written = 0;
        while (true) {
            if (esp_ota_write(handle, buf, n) != ESP_OK) { result = FlashResult::WriteFailed; break; }
            written += n;
            if (progress) progress(written, (size_t)total, ctx);
            if (written >= (size_t)total) break;
            n = fread(buf, 1, kFlashChunk, f);
            if (n == 0) { result = FlashResult::ReadFailed; break; }
        }
        if (result != FlashResult::Ok) break;

        // Valide l'image (somme de controle + hash) et l'ecrit comme valide.
        if (esp_ota_end(handle) != ESP_OK) { result = FlashResult::ValidationFailed; begun = false; break; }
        begun = false;

        if (esp_ota_set_boot_partition(target) != ESP_OK) result = FlashResult::SetBootFailed;
    } while (false);

    if (begun) esp_ota_abort(handle);
    free(buf);
    fclose(f);
    ESP_LOGI(TAG, "flash %s -> %s", path, errorKey(result));
    return result;
}

bool runningFromApp0()
{
    const esp_partition_t* run = esp_ota_get_running_partition();
    return run && run->subtype == ESP_PARTITION_SUBTYPE_APP_OTA_0;
}

FlashResult installSelfToApp1(ProgressFn progress, void* ctx)
{
    const esp_partition_t* src = esp_ota_get_running_partition();
    if (!src || src->subtype != ESP_PARTITION_SUBTYPE_APP_OTA_0) return FlashResult::NotApplicable;
    const esp_partition_t* dst =
        esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_1, nullptr);
    if (!dst) return FlashResult::NoTargetPartition;

    // Longueur reelle de l'image (en-tete + segments + somme + hash).
    esp_partition_pos_t pos = {src->address, src->size};
    esp_image_metadata_t meta;
    if (esp_image_get_metadata(&pos, &meta) != ESP_OK) return FlashResult::NotAnImage;
    const size_t total = meta.image_len;
    if (total > dst->size) return FlashResult::TooBig;

    uint8_t* buf = (uint8_t*)heap_caps_malloc(kFlashChunk, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!buf) return FlashResult::BeginFailed;

    FlashResult result = FlashResult::Ok;
    esp_ota_handle_t handle = 0;
    if (esp_ota_begin(dst, total, &handle) != ESP_OK) {
        free(buf);
        return FlashResult::BeginFailed;
    }
    for (size_t off = 0; off < total && result == FlashResult::Ok;) {
        const size_t n = (total - off < kFlashChunk) ? (total - off) : kFlashChunk;
        if (esp_partition_read(src, off, buf, n) != ESP_OK) { result = FlashResult::ReadFailed; break; }
        if (esp_ota_write(handle, buf, n) != ESP_OK) { result = FlashResult::WriteFailed; break; }
        off += n;
        if (progress) progress(off, total, ctx);
    }
    if (result == FlashResult::Ok) {
        if (esp_ota_end(handle) != ESP_OK) result = FlashResult::ValidationFailed;
        else if (esp_ota_set_boot_partition(dst) != ESP_OK) result = FlashResult::SetBootFailed;
    } else {
        esp_ota_abort(handle);
    }
    free(buf);
    ESP_LOGI(TAG, "self install app0 -> app1: %s", errorKey(result));
    return result;
}

bool selectApplication()
{
    const esp_partition_t* app = applicationPartition();
    if (!app) return false;
    uint8_t magic = 0;
    if (esp_partition_read(app, 0, &magic, 1) != ESP_OK || magic != kImageMagic) return false;
    return esp_ota_set_boot_partition(app) == ESP_OK;
}

[[noreturn]] void restart()
{
    esp_restart();
    while (true) {}
}

}  // namespace launcher
