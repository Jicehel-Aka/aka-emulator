# Launcher Gamebuino AKA (code neuf)

Launcher en C++ pour ESP-IDF 5.x / ESP32-S3, au-dessus de la bibliotheque
`components/gamebuino`. Il gere **deux dispositions de la flash**, detectees au demarrage par type/sous-type
(aucun offset en dur) :

| Disposition | Launcher | Application | Choix du demarrage |
|---|---|---|---|
| **loader/game** (bootloader modifie) | partition `loader` (app/`test`, 0x10000) | partition `game` (app/`factory`, 0x100000) | cause du reset : voir `main/launcher/README.md` et `bootloader_components/main/bootloader_start.c` ; pas d'otadata |
| **OTA** (ancienne console) | app1 (OTA_1, 0x340000) | app0 (OTA_0, 0x10000) | otadata (`esp_ota_set_boot_partition`) |

> Base : le Launcher du projet `Gamebuino_AKA_loader` (20261004), fusionne avec nos
> corrections : `screen.bmp` (le nom `screen.bpm` reste accepte), noms coupes a 38
> caracteres, texte d'aide corrige. L'ancienne version (app0/app1, OTA) est archivee
> dans `aka-launcher-ota-old.zip`.

## Fonctionnement
- Parcourt la racine de la carte SD : un dossier = une application si elle
  contient `firmware.bin` ; `meta.json` et `screen.bmp` (BMP 16/24/32 bits, ~160x120 ;
  `screen.bpm` est aussi accepte) sont facultatifs.
- **[A]** ecrit l'application choisie dans la partition du jeu (`game` ou app0 ; effacement a la
  volee, controle SHA-256 de l'image ecrite) puis redemarre dessus (loader/game : reset
  logiciel ; OTA : le Launcher selectionne app0 avant de redemarrer).
- **[D]** relit la carte SD. **[L1]+[R1]** relance la derniere application sans reinstaller.
- Retour d'un jeu au Launcher : loader/game = **reset par watchdog RTC** (cause 0x10) ; la mise
  sous tension relance aussi le Launcher. OTA = le jeu selectionne app1 puis redemarre.
- Flash direct depuis VS Code (`idf.py flash`) : le Launcher atterrit dans la partition du jeu
  (`game` / app0), se detecte (`runningAsGame()`) et se copie dans `loader` / app1. loader/game :
  il demande ensuite d'eteindre la console ; OTA : il redemarre directement dessus.
  Voir `main/launcher/README.md` pour le detail et les cas de coupure.
- **Mise a jour du Launcher depuis la SD** : poser le nouveau Launcher (`firmware.bin`) dans un
  dossier de la carte et le lancer comme une application ; il s'installe lui-meme. Le
  bootloader et la table de partitions ne changent que par USB : un Launcher loader/game ne
  fait donc pas passer une console OTA en loader/game.
- **Erreurs detaillees** : sous le message d'erreur, l'ecran affiche l'etape et le code
  (`ESP_ERR_...`), les octets ecrits, les lectures SD incompletes, la comparaison de la flash
  relue avec le fichier (`flash=fichier` / `flash!=fichier`) et la disposition detectee.
  Les memes lignes sont envoyees sur la liaison serie (tag `flasher`).
- Navigation, aide ([C]), options ([MENU]), langues : inchangees (voir `main/launcher/README.md`).

## Compiler
    # placer ou lier le composant gamebuino :
    ln -s /chemin/vers/components/gamebuino components/gamebuino
    idf.py set-target esp32s3
    idf.py build
    # flasher bootloader + table + application avec le bootloader modifie :
    idf.py flash        # (le Launcher se recopie alors dans `loader`, puis eteindre/rallumer)

## Retour d'un jeu vers le Launcher
Un jeu doit provoquer un reset par watchdog RTC (`WDT_STAGE_ACTION_RESET_RTC` sur le
RWDT), ce qui donne la cause 0x10 reconnue par le bootloader. Exemple (voir
`Loader.cpp` de BUB) :

    wdt_hal_context_t rwdt = RWDT_HAL_CONTEXT_DEFAULT();
    wdt_hal_write_protect_disable(&rwdt);
    wdt_hal_config_stage(&rwdt, WDT_STAGE0, 2000, WDT_STAGE_ACTION_RESET_RTC);
    wdt_hal_enable(&rwdt);
    wdt_hal_write_protect_enable(&rwdt);
    for (;;) {}

Attention : `WDT_STAGE_ACTION_RESET_SYSTEM` donne la cause 0x09, que le bootloader traite
comme un reset ordinaire (le jeu redemarre).

## Fichiers
| Fichier | Role |
|---|---|
| main/launcher/main.cpp | boucle principale, touches, installation |
| main/launcher/catalog.* | scan de la SD, lecture de meta.json |
| main/launcher/bmp.* | chargeur de screen.bmp vers le format natif du LCD |
| main/launcher/flasher.* | ecriture de firmware.bin dans `game`, auto-installation dans `loader` |
| main/launcher/ui.* | dessin des ecrans |
| main/launcher/settings.* | derniere application (NVS), langue |
| main/launcher/i18n.* | textes fr/en, langues de la SD, tr() |
| bootloader_components/main/bootloader_start.c | choix de la partition selon la cause du reset |
